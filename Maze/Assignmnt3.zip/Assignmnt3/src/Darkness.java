
import java.awt.Image;



/**
 *
 * @author muhammad
 */
public class Darkness extends Sprite{
    boolean exposed = false;
    public Darkness(int x, int y, int width, int height, Image img) {
        super(x, y, width, height, img);
    }
    
}
