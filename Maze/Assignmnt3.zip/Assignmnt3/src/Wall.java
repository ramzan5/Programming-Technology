import java.awt.Image;

/**
 *
 * @author muhammad
 */
public class Wall extends Sprite {

    public Wall(int x, int y, int width, int height, Image img) {
        super(x, y, width, height, img);
    }
    
}
