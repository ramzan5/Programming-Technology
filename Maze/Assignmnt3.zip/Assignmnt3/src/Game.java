

/**
 *
 * @author muhammad
 */
public class Game {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        LabyrinthGUI gui = new LabyrinthGUI();
    }
    
    
    
}
