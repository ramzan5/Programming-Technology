

/**
 *
 * @author muhammad
 */
public class Data {
    String name;
    int Scores;

    public Data(String name, int Scores) {
        this.name = name;
        this.Scores = Scores;
    }
// Gettng the Scores
    public int getScores() {
        return Scores;
    }
    
    
}
