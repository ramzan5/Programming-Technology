/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package firsttask;

/**
 *
 * @author muhammad
 */
public class Square extends Shape{
    public Square(String name, Center c, double side){
        super(name,c,side);
    }

    @Override
    public double difference() {
        double sidelength = this.getSidelength();
        return (Math.pow(sidelength, 2)) - (4 * sidelength);
       
        
    }

    @Override
    public String shapeName(){
         return this.getShape();
    }
    
    
    
}
