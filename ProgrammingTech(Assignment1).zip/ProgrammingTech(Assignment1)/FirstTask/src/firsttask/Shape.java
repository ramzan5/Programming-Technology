/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package firsttask;

/**
 *
 * @author muhammad
 */
public abstract class Shape {
    protected String shape;
    protected Center c;
    protected double sidelength;

    public Shape(String shape, Center c, double sidelength) {
        this.shape = shape;
        this.c = c;
        this.sidelength = sidelength;
    }

    public double getSidelength() {
        return sidelength;
    }

    public String getShape() {
        return shape;
    }
    
    
public abstract double difference();
public abstract String shapeName();

     
}
