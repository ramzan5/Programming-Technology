/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package firsttask;

/**
 *
 * @author muhammad
 */
public class Hexagon extends Shape{
            public Hexagon(String name, Center c, double side){
        super(name,c,side);
    }

    @Override
    public double difference() {
        double sidelength = this.getSidelength();
        return ((3*Math.sqrt(3)/2)*Math.pow(sidelength, 2)) - (6*sidelength);
        
    }

    @Override
    public String shapeName() {
        return this.getShape();
    }
            
    
    
}
