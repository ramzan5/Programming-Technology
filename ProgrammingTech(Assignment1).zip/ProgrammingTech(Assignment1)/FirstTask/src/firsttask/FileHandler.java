/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package firsttask;

import java.io.*;
import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author muhammad
 */
public class FileHandler {
    
    public void ReadFromFileAndGiveResult(ArrayList<Shape> Shapes, String fname){

     File file;
     
        while(true){
            try {
                file = new File(fname);
                if(!file.exists()) throw new FileNotFoundException();
                break;
            }
            catch(FileNotFoundException e){
                System.err.println("File does not exits , please try again.");
                break;
            }
            catch(Exception e){
                System.err.println("An unknown error occurred, please try again.");
                break;
            }          
        }
        int cline = 0; //current line
        try(BufferedReader bf = new BufferedReader(new FileReader(fname))){
        String line;
        int length = Integer.parseInt(bf.readLine());
        for(int i=0;i<length;i++){
            if( (line = bf.readLine()) == null){
                    throw new NullPointerException();
                }
            String[] Lineinfo = line.split(" ");
            if(Lineinfo.length != 4){
                    cline = i+2;
                    throw new IndexOutOfBoundsException();
                }
            String str = Lineinfo[0].toLowerCase();
                double x = Double.parseDouble(Lineinfo[1]);
                double y = Double.parseDouble(Lineinfo[2]);
                double sideLength = Double.parseDouble(Lineinfo[3]);
                switch (str){
                        case "c":
                            Shapes.add(new Circle(str,new Center(x,y), sideLength));
                            break;           
                        case "t":
                            Shapes.add(new Triangle(str,new Center(x,y), sideLength));
                            break;
                        case "s":
                            Shapes.add(new Square(str,new Center(x,y), sideLength));
                            break;
                        case "h":
                            Shapes.add(new Hexagon(str,new Center(x,y), sideLength));
                            break;
                        default:
                            cline = i+2;
                            throw new IllegalArgumentException();
                }    
        }
    double min = Shapes.get(0).difference();
    String shape = Shapes.get(0).shapeName();
    for(int i=1;i<Shapes.size();i++){    
        if(min >Shapes.get(i).difference()){
           min = Shapes.get(i).difference();
           shape = Shapes.get(i).shapeName();
        }       
    }
    System.out.println("The "+ shape + " has the smallest area-perimeter difference which is " + min );
    }

   
        catch(NullPointerException e){
            System.err.println("The number of objects do not match the first number.");
                    
        }
        catch(IllegalArgumentException e){
            System.err.println("Line " + cline + " in the file starts with an illegal character."
                    + " It should have Number.");
        }
        catch(IndexOutOfBoundsException e){
            System.err.println("There is something wrong with line " + cline + " in the file.");
        }   
        catch(IOException e){
            System.err.println("An IO exception occurred.");
        }
    }
   }  


