/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package firsttask;

/**
 *
 * @author muhammad
 */
public class Circle extends Shape{
    public Circle(String name, Center c, double side){
        super(name,c,side);
    }

    @Override
    public double difference() {
        double sidelength = this.getSidelength();
         return (Math.PI * Math.pow(sidelength, 2)) - (2 * Math.PI * sidelength); 
        
    }

    @Override
    public String shapeName() {
         return this.getShape();
    }
    
    
    
    
}
