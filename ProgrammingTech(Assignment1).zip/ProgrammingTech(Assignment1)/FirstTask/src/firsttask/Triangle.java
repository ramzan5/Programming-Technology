/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package firsttask;

/**
 *
 * @author muhammad
 */
public class Triangle extends Shape{
    public Triangle(String name, Center c, double side){
        super(name,c,side);
    }

    @Override
    public double difference() {
       double sidelength = this.getSidelength();
        return ((Math.sqrt(3)/2)*Math.pow(sidelength, 2)) - (3 * sidelength);
        
    }

    @Override
    public String shapeName() {
        return this.getShape();
    }
    
    
}
